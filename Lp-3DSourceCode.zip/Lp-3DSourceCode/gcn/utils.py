from __future__ import print_function

import numpy as np
import pickle as pkl
import networkx as nx
import scipy.io as sio
import scipy.sparse as sp
import scipy.sparse.linalg as slinalg
import scipy.linalg as linalg
from scipy.sparse.linalg.eigen.arpack import eigsh
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.preprocessing import normalize
import sys
from os import path
import copy
import os
os.environ['TF_CPP_MIN_LOG_LEVEL']='2'
import time
import random
import tensorflow as tf
from sklearn import metrics
from scipy.stats.stats import pearsonr
#from imblearn.over_sampling import SMOTE
from scipy.stats import wasserstein_distance

#import hdf5storage as hd

import logging
#import tensorflow as tf

from ppnp.tensorflow import PPNP
from ppnp.tensorflow.training import train_model
from ppnp.tensorflow.earlystopping import stopping_args
from ppnp.tensorflow.propagation import PPRExact, PPRPowerIteration
from ppnp.data.io import load_dataset
#import torch
# import matplotlib.pyplot as plt

def save_sparse_csr(filename, array):
    np.savez(filename, data=array.data, indices=array.indices,
             indptr=array.indptr, shape=array.shape)


def load_sparse_csr(filename):
    loader = np.load(filename)
    return sp.csr_matrix((loader['data'], loader['indices'], loader['indptr']),
                         shape=loader['shape'])


def parse_index_file(filename):
    """Parse index file."""
    index = []
    for line in open(filename):
        index.append(int(line.strip()))
    return index


def sample_mask(idx, l):
    """Create mask."""
    mask = np.zeros(l)
    mask[idx] = 1
    return np.array(mask, dtype=np.bool)

def get_triplet(y_train, train_mask, max_triplets):
#    print('y_train----',y_train.shape)        
    index_nonzero = y_train.nonzero()
#    for i in range(y_train.shape[1]):
#        label_count.append(index_nonzero[1][[index_nonzero[1]==i]].size)
    label_count = np.sum(y_train, axis=0)
    all_count = np.sum(label_count)
    
    index_nonzero = np.transpose(np.concatenate((index_nonzero[0][np.newaxis,:], index_nonzero[1]\
                                                 [np.newaxis, :]),axis=0)).tolist()
        
    index_nonzero = sorted(index_nonzero, key = lambda s: s[1])
    #print(index_nonzero)
    #print(label_count)
 
    def get_one_triplet(input_index, index_nonzero, label_count, all_count, max_triplets):
        triplet = []
        if label_count[input_index[1]]==0:
            return 0
        else:
 #           print('max_triplets', max_triplets)
  #          print(all_count)
   #         print(label_count[input_index[1]])
            n_triplets = min(max_triplets, int(all_count-label_count[input_index[1]]))
   #         print('----------')

            for j in range(int(label_count[input_index[1]])-1):
                positives = []
                negatives = []           
                for k, (value, label) in enumerate(index_nonzero):
                    #find a postive sample, and if only one sample then choose itself
                    if label == input_index[1] and (value != input_index[0] or label_count[input_index[1]]==1):
                        positives.append(index_nonzero[k])
                    if label != input_index[1]:
                        negatives.append(index_nonzero[k])
 #               print('positives' ,positives)
 #               print('negatives', negatives)
                negatives = random.sample(list(negatives), n_triplets)
                for value, label in negatives:
                    triplet.append([input_index[0], positives[j][0], value])
            return triplet
                
                                   
    triplet = []
    for i, j in enumerate(index_nonzero):
        triple = get_one_triplet(j, index_nonzero, label_count, all_count,max_triplets)
        
        if triple == 0:
            continue
        else:
            triplet.extend(triple)  
    np_triple = np.concatenate(np.array([triplet]), axis = 1)
    return np_triple


def load_data(dataset_str, train_size, validation_size, model_config, shuffle=True):
    """Load data."""
    if dataset_str in ['USPS-Fea', 'CIFAR-Fea', 'Cifar_10000_fea', 'Cifar_R10000_fea', 'MNIST-Fea', 'MNIST-10000', 'MNIST-5000']:
        data = sio.loadmat('data/{}.mat'.format(dataset_str))
        l = data['labels'].flatten()
        labels = np.zeros([l.shape[0],np.max(data['labels'])+1])
        labels[np.arange(l.shape[0]), l.astype(np.int8)] = 1
        features = data['X']
        sample = features[0].copy()
        adj = data['G']
    
    elif dataset_str == 'ms_academic':
        tf.logging.set_verbosity(tf.logging.INFO)
        logging.basicConfig(
        format='%(asctime)s: %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',
        level=logging.INFO)

        graph_name = 'ms_academic'
        graph = load_dataset(graph_name)
        graph.standardize(select_lcc=True)
        
        test_idx_reorder = parse_index_file("data/ind.{}.test.index".format('cora'))
        adj = graph.adj_matrix
        features = graph.attr_matrix
        labels = graph.labels
        labels[:,None] == np.unique(labels)
        labels = (labels[:,None] == np.unique(labels)).astype(int)
      
        #print("labels", *labels, sep = ",")
        #print(labels.shape)
        test_idx_range = np.sort(test_idx_reorder)
        features[test_idx_reorder, :] = features[test_idx_range, :]
        labels[test_idx_reorder, :] = labels[test_idx_range, :]
        """
        idSave={}
        idSave['Network']=adj
        idSave['Label'] = labels
        idSave['Attributes'] = features
    
        sio.savemat('CiteDataForEmbedding.mat',idSave)
        """
        features = preprocess_features(features, feature_type=model_config['feature'])        
    
    else:
        names = ['x', 'y', 'tx', 'ty', 'allx', 'ally', 'graph']
        objects = []
        for i in range(len(names)):
            with open("data/ind.{}.{}".format(dataset_str, names[i]), 'rb') as f:
                if sys.version_info > (3, 0):
                    objects.append(pkl.load(f, encoding='latin1'))
                else:
                    objects.append(pkl.load(f))

        x, y, tx, ty, allx, ally, graph = tuple(objects)
        adj = nx.adjacency_matrix(nx.from_dict_of_lists(graph))
       
        test_idx_reorder = parse_index_file("data/ind.{}.test.index".format(dataset_str))
        test_idx_range = np.sort(test_idx_reorder)

        if dataset_str == 'citeseer':
            # Fix citeseer dataset (there are some isolated nodes in the graph)
            # Find isolated nodes, add them as zero-vecs into the right position
            test_idx_range_full = range(min(test_idx_reorder), max(test_idx_reorder) + 1)
            tx_extended = sp.lil_matrix((len(test_idx_range_full), x.shape[1]))
            tx_extended[test_idx_range - min(test_idx_range), :] = tx
            tx = tx_extended
            ty_extended = np.zeros((len(test_idx_range_full), y.shape[1]))
            ty_extended[test_idx_range - min(test_idx_range), :] = ty
            ty = ty_extended

        features = sp.vstack((allx, tx)).tolil()
        labels = np.vstack((ally, ty))
        #print("TestIdxOrder", *test_idx_reorder,sep = ",")
        #print("TestIdxrange", *test_idx_range,sep = ",")
        #print("test_idx_reorder_shape", len(test_idx_reorder))
        #print("features", *features, sep = ",")
        # features = sp.eye(features.shape[0]).tolil()
        # features = sp.lil_matrix(allx)

        """
        mydata = sio.loadmat('PPIFeLaAdj.mat')
        features = mydata['features']
        labels = mydata['labels']
        adj = mydata['adj']
        """
        #features = normalize(features, norm='l2', axis=1, copy=True, return_norm=False)
        
        # labels = np.vstack(ally)

        if dataset_str.startswith('nell'):
            # Find relation nodes, add them as zero-vecs into the right position
            test_idx_range_full = range(allx.shape[0], len(graph))
            isolated_node_idx = np.setdiff1d(test_idx_range_full, test_idx_reorder)
            tx_extended = sp.lil_matrix((len(test_idx_range_full), x.shape[1]))
            tx_extended[test_idx_range - allx.shape[0], :] = tx
            tx = tx_extended
            ty_extended = np.zeros((len(test_idx_range_full), y.shape[1]))
            ty_extended[test_idx_range - allx.shape[0], :] = ty
            ty = ty_extended

            features = sp.vstack((allx, tx)).tolil()
            features[test_idx_reorder, :] = features[test_idx_range, :]
            labels = np.vstack((ally, ty))
            labels[test_idx_reorder, :] = labels[test_idx_range, :]

            idx_all = np.setdiff1d(range(len(graph)), isolated_node_idx)

            if not os.path.isfile("data/planetoid/{}.features.npz".format(dataset_str)):
                print("Creating feature vectors for relations - this might take a while...")
                features_extended = sp.hstack((features, sp.lil_matrix((features.shape[0], len(isolated_node_idx)))),
                                              dtype=np.int32).todense()
                features_extended[isolated_node_idx, features.shape[1]:] = np.eye(len(isolated_node_idx))
                features = sp.csr_matrix(features_extended, dtype=np.float32)
                print("Done!")
                save_sparse_csr("data/planetoid/{}.features".format(dataset_str), features)
            else:
                features = load_sparse_csr("data/planetoid/{}.features.npz".format(dataset_str))

            adj = nx.adjacency_matrix(nx.from_dict_of_lists(graph))
        features[test_idx_reorder, :] = features[test_idx_range, :]
        labels[test_idx_reorder, :] = labels[test_idx_range, :]
        """
        idSave={}
        idSave['Network']=adj
        idSave['Label'] = labels
        idSave['Attributes'] = features
    
        sio.savemat('CiteDataForEmbedding.mat',idSave)
        """
        features = preprocess_features(features, feature_type=model_config['feature'])
        
        #smote_nc = SMOTENC(categorical_features=[0, 2], random_state=0)
        #features, labels = smote_nc.fit_resample(features, labels)
        
        #smote = SMOTE('minority')

        #features, labels = smote.fit_sample(features, labels)
        
    global all_labels
    all_labels = labels.copy()

    # split the data set
    idx = np.arange(len(labels))
    no_class = labels.shape[1]  # number of class
    # validation_size = validation_size * len(idx) // 100
    # if not hasattr(train_size, '__getitem__'):
    train_size = [train_size for i in range(labels.shape[1])]
    if shuffle:
        np.random.shuffle(idx)
    idx_train = []
    count = [0 for i in range(no_class)]
    label_each_class = train_size
    next = 0
    for i in idx:
        if count == label_each_class:
            break
        next += 1
        for j in range(no_class):
            if labels[i, j] and count[j] < label_each_class[j]:
                idx_train.append(i)
                count[j] += 1

    test_size = model_config['test_size']
    if model_config['validate']:
        if test_size:
            assert next+validation_size<len(idx)
        idx_val = idx[next:next+validation_size]
        assert next+validation_size+test_size < len(idx)
        idx_test = idx[-test_size:] if test_size else idx[next+validation_size:]

    else:
        if test_size:
            assert next+test_size<len(idx)
        idx_val = idx[-test_size:] if test_size else idx[next:]
        idx_test = idx[-test_size:] if test_size else idx[next:]
    # else:
    #     labels_of_class = [0]
    #     while (np.prod(labels_of_class) == 0):
    #         np.random.shuffle(idx)
    #         idx_train = idx[0:int(len(idx) * train_size // 100)]
    #         labels_of_class = np.sum(labels[idx_train], axis=0)
    #     idx_val = idx[-500 - validation_size:-500]
    #     idx_test = idx[-500:]
    print('labels of each class : ', np.sum(labels[idx_train], axis=0))
    # idx_val = idx[len(idx) * train_size // 100:len(idx) * (train_size // 2 + 50) // 100]
    # idx_test = idx[len(idx) * (train_size // 2 + 50) // 100:len(idx)]
    #print("idx_train", idx_train)
    #print("idx_val", idx_val)
    #print("idx_test", idx_test)
    #cite = {}
    #cite['adj'] = adj
    #sio.savemat('pubmed.mat',cite)
    """
    idSave={}
    idSave['Network']=adj
    #idSave['idx_val']=idx_val
    #idSave['idx_test']=idx_test
    idSave['Label'] = labels
    idSave['Attributes'] = features
    
    sio.savemat('CoraDataForEmbedding.mat',idSave)
    """
    """
    loadIDs = sio.loadmat('temp.mat')
    print("*********************************************")
    #print(loadIDs['idx_train'])
    print("*********************************************")
    idx_train= loadIDs['idx_train']
    idx_val= loadIDs['idx_val']
    idx_test= loadIDs['idx_test']
    
    labels = loadIDs['labels']
    features = loadIDs['features']
    """
    train_mask = sample_mask(idx_train, labels.shape[0])
    val_mask = sample_mask(idx_val, labels.shape[0])
    test_mask = sample_mask(idx_test, labels.shape[0])

    y_train = np.zeros(labels.shape)
    y_val = np.zeros(labels.shape)
    y_test = np.zeros(labels.shape)
    y_train[train_mask, :] = labels[train_mask, :]
    y_val[val_mask, :] = labels[val_mask, :]
    y_test[test_mask, :] = labels[test_mask, :]
    #print("y_train", *y_train, sep = ",")
    """
    print("Idx train = ", *idx_train,sep =",")
    print("Number of train = ", len(idx_train))
    print("Number of test = ", len(idx_test))
    print("Number of val = ", len(idx_val))
    #print("Features = ", *features, sep = ",")
    """
    # else:
    #     idx_test = test_idx_range.tolist()
    #     idx_train = range(len(y))
    #     idx_val = range(len(y), len(y) + 500)
    #
    #     train_mask = sample_mask(idx_train, labels.shape[0])
    #     val_mask = sample_mask(idx_val, labels.shape[0])
    #     test_mask = sample_mask(idx_test, labels.shape[0])
    #
    #     y_train = np.zeros(labels.shape)
    #     y_val = np.zeros(labels.shape)
    #     y_test = np.zeros(labels.shape)
    #     y_train[train_mask, :] = labels[train_mask, :]
    #     y_val[val_mask, :] = labels[val_mask, :]
    #     y_test[test_mask, :] = labels[test_mask, :]
    
    size_of_each_class = np.sum(labels[idx_train], axis=0)
    return adj, features, y_train, y_val, y_test, train_mask, val_mask, test_mask


def sparse_to_tuple(sparse_mx):
    """Convert sparse matrix to tuple representation."""

    def to_tuple(mx):
        if not sp.isspmatrix_coo(mx):
            mx = mx.tocoo()
        coords = np.vstack((mx.row, mx.col)).transpose()
        values = mx.data
        shape = mx.shape
        return tf.SparseTensorValue(coords, values, np.array(shape, dtype=np.int64))

    if isinstance(sparse_mx, list):
        for i in range(len(sparse_mx)):
            sparse_mx[i] = to_tuple(sparse_mx[i])
    else:
        sparse_mx = to_tuple(sparse_mx)

    return sparse_mx


def preprocess_features(features, feature_type):
    if feature_type == 'bow':
        # """Row-normalize feature matrix and convert to tuple representation"""
        rowsum = np.array(features.sum(1))
        r_inv = np.power(rowsum, -1).flatten()
        r_inv[np.isinf(r_inv)] = 0.
        r_mat_inv = sp.diags(r_inv)
        features = r_mat_inv.dot(features)
        # normalize(features, norm='l1', axis=1, copy=False)
    elif feature_type == 'tfidf':
        transformer = TfidfTransformer(norm=None, use_idf=True, smooth_idf=True, sublinear_tf=False)
        features = transformer.fit_transform(features)
    elif feature_type == 'none':
        features = sp.csr_matrix(sp.eye(features.shape[0]))
    else:
        raise ValueError('Invalid feature type: ' + str(feature_type))
    return features


def normalize_adj(adj, type='sym'):
    """Symmetrically normalize adjacency matrix."""
    if type == 'sym':
        adj = sp.coo_matrix(adj)
        rowsum = np.array(adj.sum(1))
        # d_inv_sqrt = np.power(rowsum, -0.5)
        # d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.
        # return adj*d_inv_sqrt*d_inv_sqrt.flatten()
        d_inv_sqrt = np.power(rowsum, -0.5).flatten()
        d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.
        d_mat_inv_sqrt = sp.diags(d_inv_sqrt)
        return adj.dot(d_mat_inv_sqrt).transpose().dot(d_mat_inv_sqrt).tocoo()
    elif type == 'rw':
        rowsum = np.array(adj.sum(1))
        d_inv = np.power(rowsum, -1.0).flatten()
        d_inv[np.isinf(d_inv)] = 0.
        d_mat_inv = sp.diags(d_inv)
        adj_normalized = d_mat_inv.dot(adj)
        return adj_normalized


def preprocess_adj(adj, type='sym', loop=True):
    """Preprocessing of adjacency matrix for simple GCN model and conversion to tuple representation."""
    if loop:
        adj = adj + sp.eye(adj.shape[0])
    adj_normalized = normalize_adj(adj, type=type)  #
    return sparse_to_tuple(adj_normalized)


def chebyshev_polynomials(adj, k):
    """Calculate Chebyshev polynomials up to order k. Return a list of sparse matrices (tuple representation)."""
    print("Calculating Chebyshev polynomials up to order {}...".format(k))

    adj_normalized = normalize_adj(adj)
    laplacian = sp.eye(adj.shape[0]) - adj_normalized
    # largest_eigval, _ = eigsh(laplacian, 1, which='LM')
    # scaled_laplacian = (2. / largest_eigval[0]) * laplacian - sp.eye(adj.shape[0])

    t_k = list()
    t_k.append(sp.eye(adj.shape[0]))
    t_k.append(laplacian)

    def chebyshev_recurrence(t_k_minus_one, t_k_minus_two, scaled_lap):
        s_lap = sp.csr_matrix(scaled_lap, copy=True)
        return 2 * s_lap.dot(t_k_minus_one) - t_k_minus_two

    for i in range(2, k + 1):
        t_k.append(chebyshev_recurrence(t_k[-1], t_k[-2], laplacian))

    return sparse_to_tuple(t_k)


def regularized(W, alpha, stored_A = None, column = None):
    try:
        # raise Exception('DEBUG')
        A = np.load(stored_A + str(alpha) + '.npz')['arr_0']
        print('load A from ' + stored_A + str(alpha) + '.npz')
        if column is not None:
            P = np.zeros(W.shape)
            P[:, column] = A[:, column]
            return P
        else:
            return A
    except:
        # W=sp.csr_matrix([[0,1],[1,0]])
        # alpha = 1
        print('Calculate regularized probability...')
        S = normalize_adj(W, 'sym')
        L = sp.eye(S.shape[0], dtype = S.dtype) -alpha*S + 1e-6* sp.eye(W.shape[0], dtype=S.dtype)
        #L = (1-alpha)*inside
        
        
        L = sp.csc_matrix(L)
        # print(np.linalg.det(L))

        if column is not None:
            A = np.zeros(W.shape)
            # start = time.time()
            A[:, column] = slinalg.spsolve(L, sp.csc_matrix(np.eye(L.shape[0], dtype='float32')[:, column])).toarray()
            # print(time.time()-start)
            return A
        else:
            # start = time.time()
            A = slinalg.inv(L).toarray()
            # print(time.time()-start)
            if stored_A:
                np.savez(stored_A + str(alpha) + '.npz', A)
            return (1-alpha)*A
    

def absorption_probability(W, alpha, stored_A=None, column=None):
    try:
        # raise Exception('DEBUG')
        A = np.load(stored_A + str(alpha) + '.npz')['arr_0']
        print('load A from ' + stored_A + str(alpha) + '.npz')
        if column is not None:
            P = np.zeros(W.shape)
            P[:, column] = A[:, column]
            return P
        else:
            return A
    except:
        # W=sp.csr_matrix([[0,1],[1,0]])
        # alpha = 1
        n = W.shape[0]
        print('Calculate absorption probability...')
        W = W.copy().astype(np.float32)
        D = W.sum(1).flat
        L = sp.diags(D, dtype=np.float32) - W
        L += alpha * sp.eye(W.shape[0], dtype=L.dtype)
        L = sp.csc_matrix(L)
        # print(np.linalg.det(L))

        if column is not None:
            A = np.zeros(W.shape)
            # start = time.time()
            A[:, column] = slinalg.spsolve(L, sp.csc_matrix(np.eye(L.shape[0], dtype='float32')[:, column])).toarray()
            # print(time.time()-start)
            return A
        else:
            # start = time.time()
            A = slinalg.inv(L).toarray()
            # print(time.time()-start)
            if stored_A:
                np.savez(stored_A + str(alpha) + '.npz', A)
            return A
            # fletcher_reeves

            # slinalg.solve(L, np.ones(L.shape[0]))
            # A_ = np.zeros(W.shape)
            # I = sp.eye(n)
            # Di = sp.diags(np.divide(1,np.array(D)+alpha))
            # for i in range(10):
            #     # A_=
            #     A_ = Di*(I+W.dot(A_))
            # print(time.time()-start)

def absorption_probability2(W, alpha, mu, stored_A=None, column=None):
    try:
        # raise Exception('DEBUG')
        A = np.load(stored_A + str(alpha) + '.npz')['arr_0']
        print('load A from ' + stored_A + str(alpha) + '.npz')
        if column is not None:
            P = np.zeros(W.shape)
            P[:, column] = A[:, column]
            return P
        else:
            return A
    except:
        # W=sp.csr_matrix([[0,1],[1,0]])
        # alpha = 1
        #n = W.shape[0]
        #alpha = mu*alpha
        print('Calculate optimization...')
        W = W.copy().astype(np.float32)
        D = W.sum(1).flat
        L = sp.diags(D, dtype=np.float32) - W
        L = mu*L
        L = L+ alpha * sp.eye(W.shape[0], dtype=L.dtype) + (1-mu)*sp.eye(W.shape[0], dtype=L.dtype) 
        L = sp.csc_matrix(L)
        # print(np.linalg.det(L))

        if column is not None:
            A = np.zeros(W.shape)
            # start = time.time()
            A[:, column] = slinalg.spsolve(L, sp.csc_matrix(np.eye(L.shape[0], dtype='float32')[:, column])).toarray()
            # print(time.time()-start)
            return A
        else:
            # start = time.time()
            A = slinalg.inv(L).toarray()
            # print(time.time()-start)
            if stored_A:
                np.savez(stored_A + str(alpha) + '.npz', A)
            return A
            # fletcher_reeves

            # slinalg.solve(L, np.ones(L.shape[0]))
            # A_ = np.zeros(W.shape)
            # I = sp.eye(n)
            # Di = sp.diags(np.divide(1,np.array(D)+alpha))
            # for i in range(10):
            #     # A_=
            #     A_ = Di*(I+W.dot(A_))
            # print(time.time()-start)



def fletcher_reeves(A, B):
    # A=np.array(A)
    X = np.zeros(B.shape)
    r = np.array(B - A.dot(X))
    rsold = (r * r).sum(0)
    p = r
    for i in range(10):
        Ap = np.array(A.dot(p))
        pAp = (p * Ap).sum(0)
        alpha = rsold / pAp
        X += alpha * p
        r -= alpha * Ap
        rsnew = (r * r).sum(0)
        if True:
            pass
        p = r + rsnew / rsold * p
        rsold = rsnew
    return X



def fromPPREToRRWRE(aVector):
    out_arr = np.where(aVector == 1.0)
    print(out_arr)
    return out_arr

def computeProximityMatrix(A, number):
    proximityMatrix = sp.lil_matrix((number, number))
    for i in range(number):
        e = sp.lil_matrix((number,1))
        e[i] = 1
        proximityMatrix[:,i] = A.dot(e)
    return proximityMatrix

def sparsifiedTwoVectors(vec1, vec2, myeps):
    C = np.hstack([vec1, vec2])
    ind = np.zeros(C.shape[0])
    ind = ind.T
    #print("This is C ", C.shape)
    for i in range(C.shape[0]):
        if((C[i,:] < myeps).all()):
            ind[i] = 1
    #print("Indexes", ind)
    
    if(ind.sum() == 0):
        return C
    else:
        removeArray = np.where(ind == 1.0)[0]
        #print(removeArray)
        C = np.delete(C, removeArray, axis = 0)
        return C

def pCorrelation(proxMatrix, indexOfTrainNodes, AMatrix,eps):
    number = proxMatrix.shape[0]
    correlationScores = []
    x = np.asarray((AMatrix[indexOfTrainNodes,:]))
    x = x.reshape((-1, 1))
    #print("X vector", x)
    for i in range(number):
        y = np.asarray((proxMatrix[i,:]))
        y = y.reshape((-1, 1))
        if (eps == 0):
            arrayAndProb = pearsonr(x,y)
            #arrayAndProb = 10 - np.linalg.norm((x - y), ord=1)
        else:
            C = sparsifiedTwoVectors(x,y,eps)
            arrayAndProb = pearsonr(C[:,0],C[:,1])
        #print("Correlation Result: ", arrayAndProb[0])
        correlationScores.append(arrayAndProb[0])
        #print(pearsonr(x,y))
        #correlationScores.append(arrayAndProb)
    return correlationScores

def pCorrelationH(proxMatrix, indexOfTrainNodes, AMatrix,eps):
    number = proxMatrix.shape[0]
    correlationScores = []
    x = np.asarray((AMatrix[indexOfTrainNodes,:]), dtype='float')
    #x = x.reshape((-1, 1))
    #print("X vector", x)
    for i in range(number):
        y = np.asarray((proxMatrix[i,:]), dtype='float')
        #y = y.reshape((-1, 1))
        if (eps == 0):
            arrayAndProb = pearsonr(x,y)
            #arrayAndProb = 10 - np.linalg.norm((x - y), ord=1)
        else:
            C = sparsifiedTwoVectors(x,y,eps)
            arrayAndProb = pearsonr(C[:,0],C[:,1])
        #print("Correlation Result: ", arrayAndProb[0])
        correlationScores.append(arrayAndProb[0])
        #print(pearsonr(x,y))
        #correlationScores.append(arrayAndProb)
    return correlationScores


def sctraining(W, t, alpha, y_train, train_mask, stored_A=None):
    mat = sio.loadmat('Pubmed_Modularity400-0.01.mat')
    #mat = sio.loadmat('CiteRWRMatrix_0.5Alpha.mat')
    A = mat['PubmedRWRMatrix']    
    y_train = y_train.copy()
    train_index = np.where(train_mask)[0]
    already_labeled = np.sum(y_train, axis=1)
    # if not isinstance(features, np.ndarray):
    #     features = features.toarray()
    print("Additional Label:")
    if not hasattr(t, '__getitem__'):
        t = [t for _ in range(y_train.shape[1])]
    for i in range(y_train.shape[1]):
        y = y_train[:, i:i + 1]
        newIndexes = fromPPREToRRWRE(y)
        holdCorr = np.zeros(shape = (y_train.shape[0],newIndexes[0].shape[0]))
        for j in range(newIndexes[0].shape[0]):
            holdCorr[:, j] = pCorrelation(A, newIndexes[0][j],A,1e-7)
        a = holdCorr.sum(axis = 1)
        a.reshape((-1,1))
        a[already_labeled > 0] = -2
        # a[W.dot(y) > 0] = 0
        gate = (-np.sort(-a, axis=0))[t[i]]
        index = np.where(a.flat > gate)[0]

        # x1 = features[index, :].reshape((-1, 1, features.shape[1]))
        # x2 = features[y_train[:, i].astype(np.bool)].reshape((1, -1, features.shape[1]))
        # D = np.sum((x1 - x2) ** 2, axis=2) ** 0.5
        # D = np.mean(D, axis=1)
        # gate = 100000000 if t[i] >= D.shape[0] else np.sort(D, axis=0)[t[i]]
        # index = index[D<gate]
        train_index = np.hstack([train_index, index])
        y_train[index, i] = 1
        correct_label_count(index, i)
    print()
    train_mask = sample_mask(train_index, y_train.shape[0])
    return y_train, train_mask
def cotraining(W, t, alpha, y_train, train_mask, stored_A=None):
    A = absorption_probability(W, alpha, stored_A, train_mask)
    y_train = y_train.copy()
    train_index = np.where(train_mask)[0]
    already_labeled = np.sum(y_train, axis=1)
    #print(d_mat_inv)
    # if not isinstance(features, np.ndarray):
    #     features = features.toarray()
    print("Additional Label:")
    if not hasattr(t, '__getitem__'):
        t = [t for _ in range(y_train.shape[1])]
    for i in range(y_train.shape[1]):
        y = y_train[:, i:i + 1]
        a = A.dot(y)
        #a = np.divide(a, d_mat_inv) 
        a[already_labeled > 0] = 0
        # a[W.dot(y) > 0] = 0
        gate = (-np.sort(-a, axis=0))[t[i]]
        index = np.where(a.flat > gate)[0]

        # x1 = features[index, :].reshape((-1, 1, features.shape[1]))
        # x2 = features[y_train[:, i].astype(np.bool)].reshape((1, -1, features.shape[1]))
        # D = np.sum((x1 - x2) ** 2, axis=2) ** 0.5
        # D = np.mean(D, axis=1)
        # gate = 100000000 if t[i] >= D.shape[0] else np.sort(D, axis=0)[t[i]]
        # index = index[D<gate]
        train_index = np.hstack([train_index, index])
        y_train[index, i] = 1
        correct_label_count(index, i)
    print()
    train_mask = sample_mask(train_index, y_train.shape[0])
    return y_train, train_mask

def opttraining(W, t, alpha, mu, y_train, train_mask, stored_A=None):
    A = absorption_probability2(W, alpha, mu,stored_A, train_mask)
#    idSave={}
#    idSave['A']=A
#    sio.savemat('CoraOptInv.mat',idSave)
    y_train = y_train.copy()
    train_index = np.where(train_mask)[0]
    already_labeled = np.sum(y_train, axis=1)
    #print(d_mat_inv)
    # if not isinstance(features, np.ndarray):
    #     features = features.toarray()
    print("Additional Label:")
    if not hasattr(t, '__getitem__'):
        t = [t for _ in range(y_train.shape[1])]
    for i in range(y_train.shape[1]):
        y = y_train[:, i:i + 1]
        a = A.dot(y)
        #a = np.divide(a, d_mat_inv) 
        a[already_labeled > 0] = 0
        # a[W.dot(y) > 0] = 0
        gate = (-np.sort(-a, axis=0))[t[i]]
        index = np.where(a.flat > gate)[0]

        # x1 = features[index, :].reshape((-1, 1, features.shape[1]))
        # x2 = features[y_train[:, i].astype(np.bool)].reshape((1, -1, features.shape[1]))
        # D = np.sum((x1 - x2) ** 2, axis=2) ** 0.5
        # D = np.mean(D, axis=1)
        # gate = 100000000 if t[i] >= D.shape[0] else np.sort(D, axis=0)[t[i]]
        # index = index[D<gate]
        train_index = np.hstack([train_index, index])
        y_train[index, i] = 1
        correct_label_count(index, i)
    print()
    train_mask = sample_mask(train_index, y_train.shape[0])
    return y_train, train_mask


def optCorrtraining(W, t, alpha, mu, y_train, train_mask, stored_A=None):
    #A = absorption_probability2(W, alpha, mu,stored_A, train_mask)
#    idSave={}
#    idSave['A']=A
#    sio.savemat('CoraOptInv.mat',idSave)
    mat = hd.loadmat('CiteOptInv3.mat')
    A = mat['A']
    y_train = y_train.copy()
    train_index = np.where(train_mask)[0]
    already_labeled = np.sum(y_train, axis=1)
    #print(d_mat_inv)
    # if not isinstance(features, np.ndarray):
    #     features = features.toarray()
    print("Additional Label:")
    if not hasattr(t, '__getitem__'):
        t = [t for _ in range(y_train.shape[1])]
    for i in range(y_train.shape[1]):
        y = y_train[:, i:i + 1]
        a = A.dot(y)
        #a = np.divide(a, d_mat_inv) 
        a[already_labeled > 0] = 0
        # a[W.dot(y) > 0] = 0
        gate = (-np.sort(-a, axis=0))[t[i]]
        index = np.where(a.flat > gate)[0]

        # x1 = features[index, :].reshape((-1, 1, features.shape[1]))
        # x2 = features[y_train[:, i].astype(np.bool)].reshape((1, -1, features.shape[1]))
        # D = np.sum((x1 - x2) ** 2, axis=2) ** 0.5
        # D = np.mean(D, axis=1)
        # gate = 100000000 if t[i] >= D.shape[0] else np.sort(D, axis=0)[t[i]]
        # index = index[D<gate]
        train_index = np.hstack([train_index, index])
        y_train[index, i] = 1
        correct_label_count(index, i)
    print()
    train_mask = sample_mask(train_index, y_train.shape[0])
    return y_train, train_mask

def correlationtraining(W, t, alpha, mu, y_train, train_mask, stored_A=None):
     #mat = hd.loadmat('SparseCorr0001.mat')
    mat = sio.loadmat('Cite0.mat')
    A = mat['prop_ppnpC']  
     
    y_train = y_train.copy()
    train_index = np.where(train_mask)[0]
    already_labeled = np.sum(y_train, axis=1)
    #print(d_mat_inv)
    # if not isinstance(features, np.ndarray):
    #     features = features.toarray()
    print("Additional Label:")
    if not hasattr(t, '__getitem__'):
        t = [t for _ in range(y_train.shape[1])]
    for i in range(y_train.shape[1]):
        y = y_train[:, i:i + 1]
        a = A.dot(y)
        #a = np.divide(a, d_mat_inv) 
        a[already_labeled > 0] = 0
        # a[W.dot(y) > 0] = 0
        gate = (-np.sort(-a, axis=0))[t[i]]
        index = np.where(a.flat > gate)[0]

        # x1 = features[index, :].reshape((-1, 1, features.shape[1]))
        # x2 = features[y_train[:, i].astype(np.bool)].reshape((1, -1, features.shape[1]))
        # D = np.sum((x1 - x2) ** 2, axis=2) ** 0.5
        # D = np.mean(D, axis=1)
        # gate = 100000000 if t[i] >= D.shape[0] else np.sort(D, axis=0)[t[i]]
        # index = index[D<gate]
        train_index = np.hstack([train_index, index])
        y_train[index, i] = 1
        correct_label_count(index, i)
    print()
    train_mask = sample_mask(train_index, y_train.shape[0])
    return y_train, train_mask

def calc_A_hat(adj_matrix: sp.spmatrix) -> sp.spmatrix:
    #nnodes = adj_matrix.shape[0]
    A = adj_matrix 
    D_vec = np.sum(A, axis=1).A1
    D_vec_invsqrt_corr = 1 / np.sqrt(D_vec)
    D_invsqrt_corr = sp.diags(D_vec_invsqrt_corr)
    return D_invsqrt_corr @ A @ D_invsqrt_corr


def calc_ppr_exact(adj_matrix: sp.spmatrix, alpha: float) -> np.ndarray:
    nnodes = adj_matrix.shape[0]
    M = calc_A_hat2(adj_matrix)
    A_inner = sp.eye(nnodes) - (1 - alpha) * M
    return alpha * np.linalg.inv(A_inner.toarray())

def calc_A_hat2(adj_matrix: sp.spmatrix) -> sp.spmatrix:
    #nnodes = adj_matrix.shape[0]
    A = adj_matrix 
    D_vec = np.sum(A, axis=1).A1
    D_vec_invsqrt_corr = 1 / D_vec
    D_invsqrt_corr = sp.diags(D_vec_invsqrt_corr)
    return D_invsqrt_corr @ A


def calc_ppr_exact2(adj_matrix: sp.spmatrix, alpha: float) -> np.ndarray:
    nnodes = adj_matrix.shape[0]
    M = calc_A_hat2(adj_matrix)
    A_inner = sp.eye(nnodes) - (1 - alpha) * M
    return alpha * np.linalg.inv(A_inner.toarray())

def regultraining(W, t, alpha, y_train, train_mask, stored_A=None):
    A = calc_ppr_exact2(W, alpha)
    idSave={}
    idSave['A']=A
    sio.savemat('CiteOptInv.mat',idSave)
    print("Symmetrice normalized")
    y_train = y_train.copy()
    train_index = np.where(train_mask)[0]
    already_labeled = np.sum(y_train, axis=1)
    #print(d_mat_inv)
    # if not isinstance(features, np.ndarray):
    #     features = features.toarray()
    print("Additional Label:")
    if not hasattr(t, '__getitem__'):
        t = [t for _ in range(y_train.shape[1])]
    for i in range(y_train.shape[1]):
        y = y_train[:, i:i + 1]
        a = A.dot(y)
        #a = np.divide(a, d_mat_inv) 
        a[already_labeled > 0] = 0
        # a[W.dot(y) > 0] = 0
        gate = (-np.sort(-a, axis=0))[t[i]]
        index = np.where(a.flat > gate)[0]

        # x1 = features[index, :].reshape((-1, 1, features.shape[1]))
        # x2 = features[y_train[:, i].astype(np.bool)].reshape((1, -1, features.shape[1]))
        # D = np.sum((x1 - x2) ** 2, axis=2) ** 0.5
        # D = np.mean(D, axis=1)
        # gate = 100000000 if t[i] >= D.shape[0] else np.sort(D, axis=0)[t[i]]
        # index = index[D<gate]
        train_index = np.hstack([train_index, index])
        y_train[index, i] = 1
        correct_label_count(index, i)
    print()
    train_mask = sample_mask(train_index, y_train.shape[0])
    return y_train, train_mask

def regultraining2(W, t, alpha, y_train, train_mask, stored_A=None):
    A = calc_ppr_exact2(W, alpha)
    print("Regularization finished!")
    y_train = y_train.copy()
    train_index = np.where(train_mask)[0]
    already_labeled = np.sum(y_train, axis=1)
    #print(d_mat_inv)
    # if not isinstance(features, np.ndarray):
    #     features = features.toarray()
    print("Additional Label:")
    if not hasattr(t, '__getitem__'):
        t = [t for _ in range(y_train.shape[1])]
    for i in range(y_train.shape[1]):
        y = y_train[:, i:i + 1]
        a = A.dot(y)
        #a = np.divide(a, d_mat_inv) 
        a[already_labeled > 0] = 0
        # a[W.dot(y) > 0] = 0
        gate = (-np.sort(-a, axis=0))[t[i]]
        index = np.where(a.flat > gate)[0]

        # x1 = features[index, :].reshape((-1, 1, features.shape[1]))
        # x2 = features[y_train[:, i].astype(np.bool)].reshape((1, -1, features.shape[1]))
        # D = np.sum((x1 - x2) ** 2, axis=2) ** 0.5
        # D = np.mean(D, axis=1)
        # gate = 100000000 if t[i] >= D.shape[0] else np.sort(D, axis=0)[t[i]]
        # index = index[D<gate]
        train_index = np.hstack([train_index, index])
        y_train[index, i] = 1
        correct_label_count(index, i)
    print()
    train_mask = sample_mask(train_index, y_train.shape[0])
    return y_train, train_mask


def heuristictraining(W, t, alpha, y_train, train_mask, stored_A=None):
    mat = sio.loadmat('Cora_Modularity400.mat')
    
    B = mat['CoraParWalkMatrix']
    print("Size of B", B.shape)
    #mat = sio.loadmat('CiteRWRMatrix_0.01Alpha.mat')
    #A = mat['CiteRWRMatrix']
    A = absorption_probability(W, alpha, stored_A, train_mask)
    y_train = y_train.copy()
    train_index = np.where(train_mask)[0]
    already_labeled = np.sum(y_train, axis=1)
    
    
    #print(d_mat_inv)
    # if not isinstance(features, np.ndarray):
    #     features = features.toarray()
    print("Additional Label:")
    if not hasattr(t, '__getitem__'):
        t = [t for _ in range(y_train.shape[1])]
    for i in range(y_train.shape[1]):
        y = y_train[:, i:i + 1]
        a = A.dot(y)
        #print(y)
        #a = np.divide(a, d_mat_inv) 
        a[already_labeled > 0] = 0
        # a[W.dot(y) > 0] = 0
        #print("2t[i]", 2*t[i])
        kthelement = t[i] + (5/10)*t[i]
        #print("kth", kthelement)
        kthelement = int(kthelement)
        gate = (-np.sort(-a, axis=0))[kthelement]
        #print("gate= ",gate)
        index = np.where(a.flat > gate)[0]
        
        newsize = index.shape[0]
        
        newIndexes = fromPPREToRRWRE(y)
        holdCorr = np.zeros(shape = (newsize,newIndexes[0].shape[0]))
        for j in range(newIndexes[0].shape[0]):
            holdCorr[:, j] = pCorrelationH(B[index,:], newIndexes[0][j], B,0)
        b = holdCorr.sum(axis = 1)
        b.reshape((-1,1))
        order = np.argsort(b)
        newindex = order[::-1]
        newindex = newindex[0:t[i]]
        index = index[newindex]
        
        
        #print(*b, sep = ',')
        # x1 = features[index, :].reshape((-1, 1, features.shape[1]))
        # x2 = features[y_train[:, i].astype(np.bool)].reshape((1, -1, features.shape[1]))
        # D = np.sum((x1 - x2) ** 2, axis=2) ** 0.5
        # D = np.mean(D, axis=1)
        # gate = 100000000 if t[i] >= D.shape[0] else np.sort(D, axis=0)[t[i]]
        # index = index[D<gate]
        train_index = np.hstack([train_index, index])
        y_train[index, i] = 1
        correct_label_count(index, i)
    print()
    train_mask = sample_mask(train_index, y_train.shape[0])
    return y_train, train_mask

def sparseHeuristic(W, t, alpha, mu, s, y_train, train_mask, stored_A=None):
    #mat = sio.loadmat('CiteRWRMatrix_0.01Alpha.mat')
    #A = mat['CiteRWRMatrix']
    A = absorption_probability2(W, alpha, mu, stored_A, train_mask)
    y_train = y_train.copy()
    train_index = np.where(train_mask)[0]
    already_labeled = np.sum(y_train, axis=1)
    
    """ First extract the dimension D"""
    D = 50
    for i in range(y_train.shape[1]):
        y = y_train[:, i:i + 1]
        a = A.dot(y)
        a[already_labeled > 0] = 0
        gate = (-np.sort(-a, axis=0))[D]
        Dindex = np.where(a.flat > gate)[0]
    
    B = A[:, Dindex]
    print("In Sparse Heuristic B contructed with Size", B.shape)
    
    #print(d_mat_inv)
    # if not isinstance(features, np.ndarray):
    #     features = features.toarray()
    print("Additional Label:")
    if not hasattr(t, '__getitem__'):
        t = [t for _ in range(y_train.shape[1])]
    for i in range(y_train.shape[1]):
        y = y_train[:, i:i + 1]
        a = A.dot(y)
        #print(y)
        #a = np.divide(a, d_mat_inv) 
        a[already_labeled > 0] = 0
        # a[W.dot(y) > 0] = 0
        #print("2t[i]", 2*t[i])
        kthelement = t[i] + s*t[i]
        #print("kth", kthelement)
        kthelement = int(kthelement)
        gate = (-np.sort(-a, axis=0))[kthelement]
        #print("gate= ",gate)
        index = np.where(a.flat > gate)[0]
        
        newsize = index.shape[0]
        
        newIndexes = fromPPREToRRWRE(y)
        holdCorr = np.zeros(shape = (newsize,newIndexes[0].shape[0]))
        for j in range(newIndexes[0].shape[0]):
            holdCorr[:, j] = pCorrelationH(B[index,:], newIndexes[0][j], B,0)
        b = holdCorr.sum(axis = 1)
        b.reshape((-1,1))
        order = np.argsort(b)
        newindex = order[::-1]
        newindex = newindex[0:t[i]]
        index = index[newindex]
        
        
        #print(*b, sep = ',')
        # x1 = features[index, :].reshape((-1, 1, features.shape[1]))
        # x2 = features[y_train[:, i].astype(np.bool)].reshape((1, -1, features.shape[1]))
        # D = np.sum((x1 - x2) ** 2, axis=2) ** 0.5
        # D = np.mean(D, axis=1)
        # gate = 100000000 if t[i] >= D.shape[0] else np.sort(D, axis=0)[t[i]]
        # index = index[D<gate]
        train_index = np.hstack([train_index, index])
        y_train[index, i] = 1
        correct_label_count(index, i)
    print()
    train_mask = sample_mask(train_index, y_train.shape[0])
    return y_train, train_mask


def embeddingtraining(W, t, alpha, y_train, train_mask, stored_A=None):
    mat = sio.loadmat('EmbeddingPubMed.mat')
    
    B = mat['H_Net']
    #mat = sio.loadmat('CiteRWRMatrix_0.01Alpha.mat')
    #A = mat['CiteRWRMatrix']
    A = absorption_probability(W, alpha, stored_A, train_mask)
    y_train = y_train.copy()
    train_index = np.where(train_mask)[0]
    already_labeled = np.sum(y_train, axis=1)
    
    
    #print(d_mat_inv)
    # if not isinstance(features, np.ndarray):
    #     features = features.toarray()
    print("Additional Label:")
    if not hasattr(t, '__getitem__'):
        t = [t for _ in range(y_train.shape[1])]
    for i in range(y_train.shape[1]):
        y = y_train[:, i:i + 1]
        a = A.dot(y)
        #print(y)
        #a = np.divide(a, d_mat_inv) 
        a[already_labeled > 0] = 0
        # a[W.dot(y) > 0] = 0
        #print("2t[i]", 2*t[i])
        kthelement = t[i] + (5/10)*t[i]
        #print("kth", kthelement)
        kthelement = int(kthelement)
        gate = (-np.sort(-a, axis=0))[kthelement]
        #print("gate= ",gate)
        index = np.where(a.flat > gate)[0]
        
        newsize = index.shape[0]
        
        newIndexes = fromPPREToRRWRE(y)
        holdCorr = np.zeros(shape = (newsize,newIndexes[0].shape[0]))
        for j in range(newIndexes[0].shape[0]):
            holdCorr[:, j] = pCorrelationH(B[index,:], newIndexes[0][j], B,0)
        b = holdCorr.sum(axis = 1)
        b.reshape((-1,1))
        order = np.argsort(b)
        newindex = order[::-1]
        newindex = newindex[0:t[i]]
        index = index[newindex]
        
        
        #print(*b, sep = ',')
        # x1 = features[index, :].reshape((-1, 1, features.shape[1]))
        # x2 = features[y_train[:, i].astype(np.bool)].reshape((1, -1, features.shape[1]))
        # D = np.sum((x1 - x2) ** 2, axis=2) ** 0.5
        # D = np.mean(D, axis=1)
        # gate = 100000000 if t[i] >= D.shape[0] else np.sort(D, axis=0)[t[i]]
        # index = index[D<gate]
        train_index = np.hstack([train_index, index])
        y_train[index, i] = 1
        correct_label_count(index, i)
    print()
    train_mask = sample_mask(train_index, y_train.shape[0])
    return y_train, train_mask

def Aembeddingtraining(W, t, alpha, y_train, train_mask, stored_A=None):
    mat = sio.loadmat('EmbeddingPubMed.mat')
    
    B = mat['H_AANE']
    #mat = sio.loadmat('CiteRWRMatrix_0.01Alpha.mat')
    #A = mat['CiteRWRMatrix']
    A = absorption_probability(W, alpha, stored_A, train_mask)
    y_train = y_train.copy()
    train_index = np.where(train_mask)[0]
    already_labeled = np.sum(y_train, axis=1)
    
    
    #print(d_mat_inv)
    # if not isinstance(features, np.ndarray):
    #     features = features.toarray()
    print("Additional Label:")
    if not hasattr(t, '__getitem__'):
        t = [t for _ in range(y_train.shape[1])]
    for i in range(y_train.shape[1]):
        y = y_train[:, i:i + 1]
        a = A.dot(y)
        #print(y)
        #a = np.divide(a, d_mat_inv) 
        a[already_labeled > 0] = 0
        # a[W.dot(y) > 0] = 0
        #print("2t[i]", 2*t[i])
        kthelement = t[i] + (5/10)*t[i]
        #print("kth", kthelement)
        kthelement = int(kthelement)
        gate = (-np.sort(-a, axis=0))[kthelement]
        #print("gate= ",gate)
        index = np.where(a.flat > gate)[0]
        
        newsize = index.shape[0]
        
        newIndexes = fromPPREToRRWRE(y)
        holdCorr = np.zeros(shape = (newsize,newIndexes[0].shape[0]))
        for j in range(newIndexes[0].shape[0]):
            holdCorr[:, j] = pCorrelationH(B[index,:], newIndexes[0][j], B,0)
        b = holdCorr.sum(axis = 1)
        b.reshape((-1,1))
        order = np.argsort(b)
        newindex = order[::-1]
        newindex = newindex[0:t[i]]
        index = index[newindex]
        
        
        #print(*b, sep = ',')
        # x1 = features[index, :].reshape((-1, 1, features.shape[1]))
        # x2 = features[y_train[:, i].astype(np.bool)].reshape((1, -1, features.shape[1]))
        # D = np.sum((x1 - x2) ** 2, axis=2) ** 0.5
        # D = np.mean(D, axis=1)
        # gate = 100000000 if t[i] >= D.shape[0] else np.sort(D, axis=0)[t[i]]
        # index = index[D<gate]
        train_index = np.hstack([train_index, index])
        y_train[index, i] = 1
        correct_label_count(index, i)
    print()
    train_mask = sample_mask(train_index, y_train.shape[0])
    return y_train, train_mask


def featuretraining(W, t, alpha, y_train, train_mask, stored_A=None):
    mat = sio.loadmat('CoraFeatures.mat')
    
    B = mat['features']
    #mat = sio.loadmat('CiteRWRMatrix_0.01Alpha.mat')
    #A = mat['CiteRWRMatrix']
    A = absorption_probability(W, alpha, stored_A, train_mask)
    y_train = y_train.copy()
    train_index = np.where(train_mask)[0]
    already_labeled = np.sum(y_train, axis=1)
    
    
    #print(d_mat_inv)
    # if not isinstance(features, np.ndarray):
    #     features = features.toarray()
    print("Additional Label:")
    if not hasattr(t, '__getitem__'):
        t = [t for _ in range(y_train.shape[1])]
    for i in range(y_train.shape[1]):
        y = y_train[:, i:i + 1]
        a = A.dot(y)
        #print(y)
        #a = np.divide(a, d_mat_inv) 
        a[already_labeled > 0] = 0
        # a[W.dot(y) > 0] = 0
        #print("2t[i]", 2*t[i])
        kthelement = t[i] + (5/10)*t[i]
        #print("kth", kthelement)
        kthelement = int(kthelement)
        gate = (-np.sort(-a, axis=0))[kthelement]
        #print("gate= ",gate)
        index = np.where(a.flat > gate)[0]
        
        newsize = index.shape[0]
        
        newIndexes = fromPPREToRRWRE(y)
        holdCorr = np.zeros(shape = (newsize,newIndexes[0].shape[0]))
        for j in range(newIndexes[0].shape[0]):
            holdCorr[:, j] = pCorrelationH(B[index,:], newIndexes[0][j], B,0)
        b = holdCorr.sum(axis = 1)
        b.reshape((-1,1))
        order = np.argsort(b)
        newindex = order[::-1]
        newindex = newindex[0:t[i]]
        index = index[newindex]
        
        
        #print(*b, sep = ',')
        # x1 = features[index, :].reshape((-1, 1, features.shape[1]))
        # x2 = features[y_train[:, i].astype(np.bool)].reshape((1, -1, features.shape[1]))
        # D = np.sum((x1 - x2) ** 2, axis=2) ** 0.5
        # D = np.mean(D, axis=1)
        # gate = 100000000 if t[i] >= D.shape[0] else np.sort(D, axis=0)[t[i]]
        # index = index[D<gate]
        train_index = np.hstack([train_index, index])
        y_train[index, i] = 1
        correct_label_count(index, i)
    print()
    train_mask = sample_mask(train_index, y_train.shape[0])
    return y_train, train_mask


def lstraining(W, t, alpha, y_train, train_mask, stored_A=None):
    mat = sio.loadmat('PubMed_Modularity400.mat')
    
    B = mat['PubMedParWalkMatrix']
    indexGD = mat['IndexH']
    #indexGD = indexGD[0]
    #mat = sio.loadmat('CiteRWRMatrix_0.01Alpha.mat')
    #A = mat['CiteRWRMatrix']
    A = absorption_probability(W, alpha, stored_A, train_mask)
    y_train = y_train.copy()
    train_index = np.where(train_mask)[0]
    already_labeled = np.sum(y_train, axis=1)
    
    
    #print(d_mat_inv)
    # if not isinstance(features, np.ndarray):
    #     features = features.toarray()
    print("Additional Label:")
    if not hasattr(t, '__getitem__'):
        t = [t for _ in range(y_train.shape[1])]
    for i in range(y_train.shape[1]):
        y = y_train[:, i:i + 1]
       
        a = A.dot(y)
        #print(y)
        #a = np.divide(a, d_mat_inv) 
        a[already_labeled > 0] = 0
        # a[W.dot(y) > 0] = 0
        #print("2t[i]", 2*t[i])
        #kthelement = t[i] + (1/2)*t[i]
        #print("kth", kthelement)
        #kthelement = int(kthelement)
        gate = (-np.sort(-a, axis=0))[t[i]]
        #print("gate= ",gate)
        
        Parindex = np.where(a.flat > gate)[0]
        #print("Par Index",Parindex.shape)
        #print("GD Index",indexGD.shape)
        kthelement = (5/10)*t[i]
        #print("kth", kthelement)
        kthelement = int(kthelement)
        index = np.concatenate((Parindex, indexGD[i,:][0:kthelement]),axis=0)
        
        newsize = index.shape[0]
        
        newIndexes = fromPPREToRRWRE(y)
        holdCorr = np.zeros(shape = (newsize,newIndexes[0].shape[0]))
        for j in range(newIndexes[0].shape[0]):
            holdCorr[:, j] = pCorrelationH(B[index,:], newIndexes[0][j], B,0)
        b = holdCorr.sum(axis = 1)
        b.reshape((-1,1))
        order = np.argsort(b)
        newindex = order[::-1]
        newindex = newindex[0:t[i]]
        index = index[newindex]
        
        #print(*b, sep = ',')
        # x1 = features[index, :].reshape((-1, 1, features.shape[1]))
        # x2 = features[y_train[:, i].astype(np.bool)].reshape((1, -1, features.shape[1]))
        # D = np.sum((x1 - x2) ** 2, axis=2) ** 0.5
        # D = np.mean(D, axis=1)
        # gate = 100000000 if t[i] >= D.shape[0] else np.sort(D, axis=0)[t[i]]
        # index = index[D<gate]
        train_index = np.hstack([train_index, index])
        y_train[index, i] = 1
        correct_label_count(index, i)
    print()
    train_mask = sample_mask(train_index, y_train.shape[0])
    return y_train, train_mask

def lstraining2(W, t, alpha, y_train, train_mask, stored_A=None):
    mat = sio.loadmat('EmbeddingPubMed.mat')
    
    B = mat['H_Net']
    mat = sio.loadmat('PubMed_Modularity400.mat')
    indexGD = mat['IndexH']
    #indexGD = indexGD[0]
    #mat = sio.loadmat('CiteRWRMatrix_0.01Alpha.mat')
    #A = mat['CiteRWRMatrix']
    A = absorption_probability(W, alpha, stored_A, train_mask)
    y_train = y_train.copy()
    train_index = np.where(train_mask)[0]
    already_labeled = np.sum(y_train, axis=1)
    
    
    #print(d_mat_inv)
    # if not isinstance(features, np.ndarray):
    #     features = features.toarray()
    print("Additional Label:")
    if not hasattr(t, '__getitem__'):
        t = [t for _ in range(y_train.shape[1])]
    for i in range(y_train.shape[1]):
        y = y_train[:, i:i + 1]
       
        a = A.dot(y)
        #print(y)
        #a = np.divide(a, d_mat_inv) 
        a[already_labeled > 0] = 0
        # a[W.dot(y) > 0] = 0
        #print("2t[i]", 2*t[i])
        #kthelement = t[i] + (1/2)*t[i]
        #print("kth", kthelement)
        #kthelement = int(kthelement)
        gate = (-np.sort(-a, axis=0))[t[i]]
        #print("gate= ",gate)
        
        Parindex = np.where(a.flat > gate)[0]
        #print("Par Index",Parindex.shape)
        #print("GD Index",indexGD.shape)
        kthelement = (5/10)*t[i]
        #print("kth", kthelement)
        kthelement = int(kthelement)
        index = np.concatenate((Parindex, indexGD[i,:][0:kthelement]),axis=0)
        
        newsize = index.shape[0]
        
        newIndexes = fromPPREToRRWRE(y)
        holdCorr = np.zeros(shape = (newsize,newIndexes[0].shape[0]))
        for j in range(newIndexes[0].shape[0]):
            holdCorr[:, j] = pCorrelationH(B[index,:], newIndexes[0][j], B,0)
        b = holdCorr.sum(axis = 1)
        b.reshape((-1,1))
        order = np.argsort(b)
        newindex = order[::-1]
        newindex = newindex[0:t[i]]
        index = index[newindex]
        
        #print(*b, sep = ',')
        # x1 = features[index, :].reshape((-1, 1, features.shape[1]))
        # x2 = features[y_train[:, i].astype(np.bool)].reshape((1, -1, features.shape[1]))
        # D = np.sum((x1 - x2) ** 2, axis=2) ** 0.5
        # D = np.mean(D, axis=1)
        # gate = 100000000 if t[i] >= D.shape[0] else np.sort(D, axis=0)[t[i]]
        # index = index[D<gate]
        train_index = np.hstack([train_index, index])
        y_train[index, i] = 1
        correct_label_count(index, i)
    print()
    train_mask = sample_mask(train_index, y_train.shape[0])
    return y_train, train_mask

def heightraining(W, t, alpha, y_train, train_mask, stored_A=None):
    mat = sio.loadmat('Cora_Modularity400.mat')
    
    B = mat['CoraParWalkMatrix']
    indexGD = mat['IndexH']
    #indexGD = indexGD[0]
    #mat = sio.loadmat('CiteRWRMatrix_0.01Alpha.mat')
    #A = mat['CiteRWRMatrix']
    A = absorption_probability(W, alpha, stored_A, train_mask)
    y_train = y_train.copy()
    train_index = np.where(train_mask)[0]
    already_labeled = np.sum(y_train, axis=1)
    
    
    #print(d_mat_inv)
    # if not isinstance(features, np.ndarray):
    #     features = features.toarray()
    print("Additional Label:")
    if not hasattr(t, '__getitem__'):
        t = [t for _ in range(y_train.shape[1])]
    for i in range(y_train.shape[1]):
        y = y_train[:, i:i + 1]
       
        a = A.dot(y)
        #print(y)
        #a = np.divide(a, d_mat_inv) 
        a[already_labeled > 0] = 0
        # a[W.dot(y) > 0] = 0
        #print("2t[i]", 2*t[i])
        #kthelement = t[i] + (1/2)*t[i]
        #print("kth", kthelement)
        #kthelement = int(kthelement)
        gate = (-np.sort(-a, axis=0))[t[i]]
        #print("gate= ",gate)
        
        Parindex = np.where(a.flat > gate)[0]
        #print("Par Index",Parindex.shape)
        #print("GD Index",indexGD.shape)
        kthelement = (3/10)*t[i]
        #print("kth", kthelement)
        kthelement = int(kthelement)
        index = np.concatenate((Parindex, indexGD[i,:][0:kthelement]),axis=0)
        
        newsize = index.shape[0]
        
        newIndexes = fromPPREToRRWRE(y)
        holdCorr = np.zeros(shape = (newsize,newIndexes[0].shape[0]))
        for j in range(newIndexes[0].shape[0]):
            holdCorr[:, j] = pCorrelationH(B[index,:], newIndexes[0][j], B,0)
        b = holdCorr.sum(axis = 1)
        b.reshape((-1,1))
        order = np.argsort(b)
        newindex = order[::-1]
        newindex = newindex[0:t[i]]
        index = index[newindex]
        
        #print(*b, sep = ',')
        # x1 = features[index, :].reshape((-1, 1, features.shape[1]))
        # x2 = features[y_train[:, i].astype(np.bool)].reshape((1, -1, features.shape[1]))
        # D = np.sum((x1 - x2) ** 2, axis=2) ** 0.5
        # D = np.mean(D, axis=1)
        # gate = 100000000 if t[i] >= D.shape[0] else np.sort(D, axis=0)[t[i]]
        # index = index[D<gate]
        train_index = np.hstack([train_index, index])
        y_train[index, i] = 1
        correct_label_count(index, i)
    print()
    train_mask = sample_mask(train_index, y_train.shape[0])
    return y_train, train_mask
def gctraining(W, t, alpha, y_train, train_mask, stored_A=None):
    mat = sio.loadmat('Cora_Modularity400.mat')
    
    B = mat['CoraParWalkMatrix']
    indexGD = mat['IndexGC']
    #indexGD = indexGD[0]
    #mat = sio.loadmat('CiteRWRMatrix_0.01Alpha.mat')
    #A = mat['CiteRWRMatrix']
    A = absorption_probability(W, alpha, stored_A, train_mask)
    y_train = y_train.copy()
    train_index = np.where(train_mask)[0]
    already_labeled = np.sum(y_train, axis=1)
    
    
    #print(d_mat_inv)
    # if not isinstance(features, np.ndarray):
    #     features = features.toarray()
    print("Additional Label:")
    if not hasattr(t, '__getitem__'):
        t = [t for _ in range(y_train.shape[1])]
    for i in range(y_train.shape[1]):
        y = y_train[:, i:i + 1]
       
        a = A.dot(y)
        #print(y)
        #a = np.divide(a, d_mat_inv) 
        a[already_labeled > 0] = 0
        # a[W.dot(y) > 0] = 0
        #print("2t[i]", 2*t[i])
        #kthelement = t[i] + (1/2)*t[i]
        #print("kth", kthelement)
        #kthelement = int(kthelement)
        gate = (-np.sort(-a, axis=0))[t[i]]
        #print("gate= ",gate)
        
        Parindex = np.where(a.flat > gate)[0]
        #print("Par Index",Parindex.shape)
        #print("GD Index",indexGD.shape)
        kthelement = (10/10)*t[i]
        #print("kth", kthelement)
        kthelement = int(kthelement)
        index = np.concatenate((Parindex, indexGD[i,:][0:kthelement]),axis=0)
        
        newsize = index.shape[0]
        
        newIndexes = fromPPREToRRWRE(y)
        holdCorr = np.zeros(shape = (newsize,newIndexes[0].shape[0]))
        for j in range(newIndexes[0].shape[0]):
            holdCorr[:, j] = pCorrelationH(B[index,:], newIndexes[0][j], B,0)
        b = holdCorr.sum(axis = 1)
        b.reshape((-1,1))
        order = np.argsort(b)
        newindex = order[::-1]
        newindex = newindex[0:t[i]]
        index = index[newindex]
        
        #print(*b, sep = ',')
        # x1 = features[index, :].reshape((-1, 1, features.shape[1]))
        # x2 = features[y_train[:, i].astype(np.bool)].reshape((1, -1, features.shape[1]))
        # D = np.sum((x1 - x2) ** 2, axis=2) ** 0.5
        # D = np.mean(D, axis=1)
        # gate = 100000000 if t[i] >= D.shape[0] else np.sort(D, axis=0)[t[i]]
        # index = index[D<gate]
        train_index = np.hstack([train_index, index])
        y_train[index, i] = 1
        correct_label_count(index, i)
    print()
    train_mask = sample_mask(train_index, y_train.shape[0])
    return y_train, train_mask
def hgctraining(W, t, alpha, y_train, train_mask, stored_A=None):
    mat = sio.loadmat('Cora_Modularity400.mat')
    
    B = mat['CoraParWalkMatrix']
    indexGD = mat['IndexHGC']
    #indexGD = indexGD[0]
    #mat = sio.loadmat('CiteRWRMatrix_0.01Alpha.mat')
    #A = mat['CiteRWRMatrix']
    A = absorption_probability(W, alpha, stored_A, train_mask)
    y_train = y_train.copy()
    train_index = np.where(train_mask)[0]
    already_labeled = np.sum(y_train, axis=1)
    
    
    #print(d_mat_inv)
    # if not isinstance(features, np.ndarray):
    #     features = features.toarray()
    print("Additional Label:")
    if not hasattr(t, '__getitem__'):
        t = [t for _ in range(y_train.shape[1])]
    for i in range(y_train.shape[1]):
        y = y_train[:, i:i + 1]
       
        a = A.dot(y)
        #print(y)
        #a = np.divide(a, d_mat_inv) 
        a[already_labeled > 0] = 0
        # a[W.dot(y) > 0] = 0
        #print("2t[i]", 2*t[i])
        #kthelement = t[i] + (1/2)*t[i]
        #print("kth", kthelement)
        #kthelement = int(kthelement)
        gate = (-np.sort(-a, axis=0))[t[i]]
        #print("gate= ",gate)
        
        Parindex = np.where(a.flat > gate)[0]
        #print("Par Index",Parindex.shape)
        #print("GD Index",indexGD.shape)
        kthelement = (1/10)*t[i]
        #print("kth", kthelement)
        kthelement = int(kthelement)
        index = np.concatenate((Parindex, indexGD[i,:][0:kthelement]),axis=0)
        
        newsize = index.shape[0]
        
        newIndexes = fromPPREToRRWRE(y)
        holdCorr = np.zeros(shape = (newsize,newIndexes[0].shape[0]))
        for j in range(newIndexes[0].shape[0]):
            holdCorr[:, j] = pCorrelationH(B[index,:], newIndexes[0][j], B,0)
        b = holdCorr.sum(axis = 1)
        b.reshape((-1,1))
        order = np.argsort(b)
        newindex = order[::-1]
        newindex = newindex[0:t[i]]
        index = index[newindex]
        
        #print(*b, sep = ',')
        # x1 = features[index, :].reshape((-1, 1, features.shape[1]))
        # x2 = features[y_train[:, i].astype(np.bool)].reshape((1, -1, features.shape[1]))
        # D = np.sum((x1 - x2) ** 2, axis=2) ** 0.5
        # D = np.mean(D, axis=1)
        # gate = 100000000 if t[i] >= D.shape[0] else np.sort(D, axis=0)[t[i]]
        # index = index[D<gate]
        train_index = np.hstack([train_index, index])
        y_train[index, i] = 1
        correct_label_count(index, i)
    print()
    train_mask = sample_mask(train_index, y_train.shape[0])
    return y_train, train_mask

def WDist(proxMatrix, indexOfTrainNodes):
    number = proxMatrix.shape[1]
    correlationScores = []
    x = np.asarray((proxMatrix[indexOfTrainNodes,:]))
    #x = x.reshape((-1, 1))
    #print("X vector", x)
    for i in range(number):
        y = np.asarray((proxMatrix[:,i]))
        #y = y.reshape((-1, 1))
        #C = sparsifiedTwoVectors(x,y,1e-5)
        #arrayAndProb = pearsonr(C[:,0],C[:,1])
        #print("Correlation Result: ", arrayAndProb[0])
        score = 10 - np.linalg.norm((x - y), ord=1)
        #print("score",score)
        correlationScores.append(score)
        #print(pearsonr(x,y))
    return correlationScores
def WDtraining(W, t, alpha, y_train, train_mask, stored_A=None):
    mat = sio.loadmat('CiteRWRMatrix_3Alpha.mat')
    A = mat['CiteRWRMatrix']    
    y_train = y_train.copy()
    train_index = np.where(train_mask)[0]
    already_labeled = np.sum(y_train, axis=1)
    # if not isinstance(features, np.ndarray):
    #     features = features.toarray()
    print("Additional Label:")
    if not hasattr(t, '__getitem__'):
        t = [t for _ in range(y_train.shape[1])]
    for i in range(y_train.shape[1]):
        y = y_train[:, i:i + 1]
        newIndexes = fromPPREToRRWRE(y)
        print("New Index size is the training size? = ", newIndexes[0].shape[0])
        holdCorr = np.zeros(shape = (y_train.shape[0],newIndexes[0].shape[0]))
        for j in range(newIndexes[0].shape[0]):
            holdCorr[:, j] = WDist(A, newIndexes[0][j])
        a = holdCorr.sum(axis = 1)
        a.reshape((-1,1))
        a[already_labeled > 0] = 0
        # a[W.dot(y) > 0] = 0
        gate = (-np.sort(-a, axis=0))[t[i]]
        index = np.where(a.flat > gate)[0]

        # x1 = features[index, :].reshape((-1, 1, features.shape[1]))
        # x2 = features[y_train[:, i].astype(np.bool)].reshape((1, -1, features.shape[1]))
        # D = np.sum((x1 - x2) ** 2, axis=2) ** 0.5
        # D = np.mean(D, axis=1)
        # gate = 100000000 if t[i] >= D.shape[0] else np.sort(D, axis=0)[t[i]]
        # index = index[D<gate]
        train_index = np.hstack([train_index, index])
        y_train[index, i] = 1
        correct_label_count(index, i)
    print()
    train_mask = sample_mask(train_index, y_train.shape[0])
    return y_train, train_mask

def selftraining(prediction, t, y_train, train_mask):
    new_gcn_index = np.argmax(prediction, axis=1)
    confidence = np.max(prediction, axis=1)
    sorted_index = np.argsort(-confidence)

    no_class = y_train.shape[1]  # number of class
    if hasattr(t, '__getitem__'):
        assert len(t) >= no_class
        index = []
        count = [0 for i in range(no_class)]
        for i in sorted_index:
            for j in range(no_class):
                if new_gcn_index[i] == j and count[j] < t[j] and not train_mask[i]:
                    index.append(i)
                    count[j] += 1
    else:
        index = sorted_index[:t]
    indicator = np.zeros(train_mask.shape, dtype=np.bool)
    indicator[index] = True
    indicator = np.logical_and(np.logical_not(train_mask), indicator)

    prediction = np.zeros(prediction.shape)
    prediction[np.arange(len(new_gcn_index)), new_gcn_index] = 1.0
    prediction[train_mask] = y_train[train_mask]

    correct_labels = np.sum(prediction[indicator] * all_labels[indicator], axis=0)
    count = np.sum(prediction[indicator], axis=0)
    print('Additiona Label:')
    for i, j in zip(correct_labels, count):
        print(int(i), '/', int(j), sep='', end='\t')
    print()

    y_train = np.copy(y_train)
    train_mask = np.copy(train_mask)
    train_mask[indicator] = 1
    y_train[indicator] = prediction[indicator]
    return y_train, train_mask


def lp(adj, alpha, y_train, train_mask, y_test, stored_A=None):
    P = absorption_probability(adj, alpha, stored_A=stored_A, column=train_mask)
    P = P[:, train_mask]

    # nearest clssifier
    predicted_labels = np.argmax(P, axis=1)
    # prediction = alpha*P
    prediction = np.zeros(P.shape)
    prediction[np.arange(P.shape[0]), predicted_labels] = 1

    y = np.sum(train_mask)
    label_per_sample = np.vstack([np.zeros(y), np.eye(y)])[np.add.accumulate(train_mask) * train_mask]
    sample2label = label_per_sample.T.dot(y_train)
    prediction = prediction.dot(sample2label)
    #print("y_test", *y_test, sep = ",")
    #print("y_test size", y_test.shape)
    #print("prediction ", *prediction, sep = ",")
    #print("prediction size", prediction.shape)
    test_acc = np.sum(prediction * y_test) / np.sum(y_test)
    test_acc_of_class = np.sum(prediction * y_test, axis=0) / np.sum(y_test, axis=0)
    # print(test_acc, test_acc_of_class)
    #metrics.classification_report(y_test, prediction, labels=[0,1])
    return test_acc, test_acc_of_class, prediction


def union_intersection(prediction, t, y_train, train_mask, W, alpha, stored_A, union_or_intersection):
    no_class = y_train.shape[1]  # number of class

    # gcn index
    new_labels_gcn = np.argmax(prediction, axis=1)
    confidence = np.max(prediction, axis=1)
    sorted_index = np.argsort(-confidence)

    if not hasattr(t, '__getitem__'):
        t = [t for i in range(no_class)]

    assert len(t) >= no_class
    count = [0 for i in range(no_class)]
    index_gcn = [[] for i in range(no_class)]
    for i in sorted_index:
        j = new_labels_gcn[i]
        if count[j] < t[j] and not train_mask[i]:
            index_gcn[j].append(i)
            count[j] += 1

    # lp
    A = absorption_probability(W, alpha, stored_A, train_mask)
    train_index = np.where(train_mask)[0]
    already_labeled = np.sum(y_train, axis=1)
    index_lp = []
    for i in range(no_class):
        y = y_train[:, i:i + 1]
        a = np.sum(A[:, y.flat > 0], axis=1)
        a[already_labeled > 0] = 0
        # a[W.dot(y) > 0] = 0
        gate = (-np.sort(-a, axis=0))[t[i]]
        index = np.where(a.flat > gate)[0]
        index_lp.append(index)

    # print(list(map(len, index_gcn)))
    # print(list(map(len, index_lp)))

    y_train = y_train.copy()
    print("Additional Label:")
    for i in range(no_class):
        assert union_or_intersection in ['union', 'intersection']
        if union_or_intersection == 'union':
            index = list(set(index_gcn[i]) | set(index_lp[i]))
        else:
            index = list(set(index_gcn[i]) & set(index_lp[i]))
        y_train[index, i] = 1
        train_mask[index] = True
        print(np.sum(all_labels[index, i]), '/', len(index), sep='', end='\t')
    return y_train, train_mask


def ap_approximate(adj, features, alpha, k):
    adj = normalize(adj + sp.eye(adj.shape[0]), 'l1', axis=1) / (alpha + 1)
    # D = sp.diags(np.array(adj.sum(axis=1)).flatten())+alpha*sp.eye(adj.shape[0])
    # D = D.power(-1)
    # adj = D*adj
    # features = D*alpha*features
    if sp.issparse(features):
        features = features.toarray()
    new_feature = np.zeros(features.shape)
    for _ in range(k):
        new_feature = adj * new_feature + features
    new_feature *= alpha / (alpha + 1)
    return new_feature

all_labels = None


# dataset = None

def correct_label_count(indicator, i):
    count = np.sum(all_labels[:, i][indicator])
    if indicator.dtype == np.bool:
        total = np.where(indicator)[0].shape[0]
    elif indicator.dtype in [np.int, np.int8, np.int16, np.int32, np.int64]:
        total = indicator.shape[0]
    else:
        raise TypeError('indicator must be of data type np.bool or np.int')
    # print("     for class {}, {}/{} is correct".format(i, count, total))
    print(count, '/', total, sep='', end='\t')


def construct_feed_dict(features, support, labels, labels_mask, placeholders):
    """Construct feed dictionary."""
    feed_dict = dict()
    feed_dict.update({placeholders['labels']: labels})
    feed_dict.update({placeholders['labels_mask']: labels_mask})
    feed_dict.update({placeholders['features']: features})
    feed_dict.update({placeholders['support'][i]: support[i] for i in range(len(support))})
    feed_dict.update({placeholders['num_features_nonzero']: features[1].shape})
    return feed_dict


def preprocess_model_config(model_config):
    if model_config['Model'] not in [17, 23]:
        model_config['connection'] = list(model_config['connection'])
        # judge if parameters are legal
        for c in model_config['connection']:
            if c not in ['c', 'd', 'r', 'f', 'C']:
                raise ValueError(
                    'connection string specified by --connection can only contain "c", "d", "r", "f", "C" but "{}" found'.format(
                        c))
        for i in model_config['layer_size']:
            if not isinstance(i, int):
                raise ValueError('layer_size should be a list of int, but found {}'.format(model_config['layer_size']))
            if i <= 0:
                raise ValueError('layer_size must be greater than 0, but found {}' % i)
        if not len(model_config['connection']) == len(model_config['layer_size']) + 1:
            raise ValueError('length of connection string should be equal to length of layer_size list plus 1')

    # Generate name
    if not model_config['name']:
        model_name = str(model_config['Model'])
        if model_config['Model'] != 'lp':
            model_name += '_' + model_config['connection'][0]
            for char, size in \
                    zip(model_config['connection'][1:], model_config['layer_size']):
                model_name += str(size) + char

            if model_config['conv'] == 'cheby':
                model_name += '_cheby' + str(model_config['max_degree'])
            elif model_config['conv'] == 'taubin':
                model_name += '_conv_taubin' + str(model_config['taubin_lambda']) \
                              + '_' + str(model_config['taubin_mu']) \
                              + '_' + str(model_config['taubin_repeat'])
            elif model_config['conv'] == 'test21':
                model_name += '_' + 'conv_test21' + '_' + str(model_config['alpha']) + '_' + str(model_config['beta'])
            elif model_config['conv'] == 'gcn_unnorm':
                model_name += '_' + 'gcn_unnorm'
            elif model_config['conv'] == 'gcn_noloop':
                model_name += '_' + 'gcn_noloop'
            if model_config['validate']:
                model_name += '_validate'

        if model_config['Model'] == 'cotraining':
            model_name += '_alpha_' + str(
                model_config['alpha'])
        # if model_config['Model'] == 'selftraining':
        #     Model_to_add_label = copy.deepcopy(model_config)
        #     if 'Model_to_add_label' in Model_to_add_label:
        #         del Model_to_add_label['Model_to_add_label']
        #     if 'Model_to_predict' in Model_to_add_label:
        #         del Model_to_add_label['Model_to_predict']
        #     Model_to_add_label.update({'Model': 'GCN'})
        #     model_config['Model_to_add_label'] = Model_to_add_label
        #     preprocess_model_config(model_config['Model_to_add_label'])
        #
        #     Model_to_predict = copy.deepcopy(model_config)
        #     if 'Model_to_add_label' in Model_to_predict:
        #         del Model_to_predict['Model_to_add_label']
        #     if 'Model_to_predict' in Model_to_predict:
        #         del Model_to_predict['Model_to_predict']
        #     Model_to_predict.update({'Model': 'GCN'})
        #     model_config['Model_to_predict'] = Model_to_predict
        #     preprocess_model_config(model_config['Model_to_predict'])
        #     model_name = 'Model' + str(model_config['Model']) \
        #                  + '_{' + model_config['Model_to_add_label']['name'] + '}' \
        #                  + '_{' + model_config['Model_to_predict']['name'] + '}'
        if model_config['Model'] in ['union', 'intersection','lp']:
            model_name += '_alpha_' + str(model_config['alpha'])

        if model_config['Model'] in ['union', 'intersection', 'selftraining']:
            Model_to_add_label = copy.deepcopy(model_config)
            if 'Model_to_add_label' in Model_to_add_label:
                del Model_to_add_label['Model_to_add_label']
            if 'Model_to_predict' in Model_to_add_label:
                del Model_to_add_label['Model_to_predict']
            Model_to_add_label.update({'Model': 'GCN'})
            model_config['Model_to_add_label'] = Model_to_add_label
            preprocess_model_config(model_config['Model_to_add_label'])

            Model_to_predict = copy.deepcopy(model_config)
            if 'Model_to_add_label' in Model_to_predict:
                del Model_to_predict['Model_to_add_label']
            if 'Model_to_predict' in Model_to_predict:
                del Model_to_predict['Model_to_predict']
            Model_to_predict.update({'Model': 'GCN'})
            model_config['Model_to_predict'] = Model_to_predict
            preprocess_model_config(model_config['Model_to_predict'])


        model_config['name'] = model_name


if __name__ == '__main__':
    pass