# -*- coding: utf-8 -*-
"""
Created on Mon Jul 29 08:23:47 2019

@author: Secil
"""

for j in range(2):
    print(j)
